"""Chief Scientist Tech Task file for ensuring the package is executable
as `cds-tech-task` and `python -m cds_tech_task`
"""
from .cli import run_cli


def main():
    run_cli()


if __name__ == "__main__":
    main()
