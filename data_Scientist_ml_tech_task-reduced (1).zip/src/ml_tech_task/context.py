import logging
from logging.config import dictConfig
from pathlib import Path
from typing import Any, Dict
import yaml
import os


class ProjectContext():

    def __init__(self, package_name: str = None):
        self.project_path = Path(os.path.dirname(__file__)).parents[1]
        self.package_name = package_name
        self._parameters = self._get_parameters()
        self._catalog = self._get_catalog()
        self._setup_logger()

    @property
    def parameters(self) -> Dict[str, Any]:
        """Write protected parameters"""
        return self._parameters

    def set_tune_hyper_parameters(self, value: bool):
        """Enable overwrite of tune_hyper_parameters"""
        self._parameters['hyper_parameters']['tune_hyper_parameters'] = value

    @property
    def catalog(self) -> Dict[str, Any]:
        """Write protected data catalog"""
        return self._catalog

    def _get_catalog(self) -> Dict[str, Any]:
        """Get data catalog upon instantiation"""
        conf_path = os.path.join(self.project_path, 'conf', 'catalog.yml')

        with open(conf_path, "r") as f:
            catalog = yaml.safe_load(f)
        return catalog

    def _get_parameters(self) -> Dict[str, Any]:
        """Get parameters upon instantiation"""
        conf_path = os.path.join(self.project_path, 'conf', 'parameters.yml')
        with open(conf_path, "r") as f:
            parameters = yaml.safe_load(f)
        return parameters

    def _setup_logger(self):
        """Setup logging parameters"""
        conf_path = os.path.join(self.project_path, 'conf', 'logging.yml')

        with open(conf_path, "r") as f:
            logging_params = yaml.safe_load(f)

        for handler_key in logging_params['handlers']:
            try:
                filepath = logging_params['handlers'][handler_key]['filename']
                filepath = os.path.join(self.project_path, filepath)
                logging_params['handlers'][handler_key]['filename'] = filepath
            except KeyError:
                pass

        dictConfig(logging_params)
        logging.info('LOGGING STARTED')


