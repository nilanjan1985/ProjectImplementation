import random
import logging
from typing import Tuple, Any

import numpy as np
import pandas as pd
from pandas import DataFrame
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


def get_feature_dataset_from_file(filename: str) -> DataFrame:
    """Load primary data"""
    log = logging.getLogger(__name__)
    log.info('Loading data')
    df = pd.read_csv(filename)
    return df


def remove_infinities(df: DataFrame) -> DataFrame:
    """Turn infinities into nan type, so that xgboost can handle them better."""
    log = logging.getLogger(__name__)
    log.info('Removing infinities')
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            df.loc[np.isinf(df[col]), col] = np.nan
    return df


def transform_features(df: DataFrame) -> Tuple[DataFrame, LabelEncoder]:
    """Transform primary data into dataframe with features and targets."""
    log = logging.getLogger(__name__)
    log.info('Get features and targets')
    cols_to_keep = ['ctr_total_3m',
                    'ctr_apps_3m',
                    'ctr_auto_3m',
                    'ctr_ecommerce_3m',
                    'ctr_gaming_3m',
                    'ctr_healthcare_3m',
                    'ctr_unknown_3m',
                    'n_imps_total_3m',
                    'price_range',
                    'gender',
                    'age_group',
                    'region',
                    'country']

    # We remove columns we want to ignore in this model
    cols_to_drop = [col not in cols_to_keep for col in df.columns]
    df_transformed = df.drop(df.loc[:, cols_to_drop].columns, axis=1)

    # encode strings into categorical data
    categorical_labels = ['price_range', 'age_group', 'gender', 'region', 'country']
    encoder_labels = LabelEncoder()
    for col in categorical_labels:
        df_transformed[col] = encoder_labels.fit_transform(df_transformed[col].astype(str))

    return (df_transformed, encoder_labels)


def generate_seed() -> int:
    """Generate a random integer between 0 and 1E9"""
    seed = random.randint(0, int(1E9))
    log = logging.getLogger(__name__)
    log.info(f'Random seed generated: {seed}')
    return seed


def split_data(df_transformed: DataFrame, test_ratio: float, seed: int) -> Tuple[Any, Any]:
    """IMPLEMENT THIS FUNCTION.
    use this function to divide the data in a way that enables you to train predictive models
    most effectively. You should gain an understanding of the data and adapt your approach accordingly.
    :param df_transformed: This should be the output from transform_features()
    :param test_ratio: test/train split
    :param seed: integer to define a random state (usage optional)
    :return: training_data, testing_data: data split between train and test.
     can be different to input data type.
    """
    # TODO: START: Your code below VVV
    # TODO: END: Your code above ^^^
    return training_data, testing_data

