import logging
from typing import Any, Dict

from xgboost import XGBRegressor
from pandas import DataFrame
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RepeatedKFold
from sklearn import metrics


def tune_hyper_parameters(X_train: DataFrame, y_train: DataFrame, params: Dict[str, Any]) -> Dict[str, Any]:
    """Tune model hyper parameters based on cross-validation"""
    # get parameters
    seed = params['seed']['seed_val']
    num_cv_iter = params['cross_validation']['num_cv_iter']
    num_folds = params['cross_validation']['folds']
    num_cores = params['cross_validation']['num_cores']
    hyper_param_ranges = params['hyper_param_ranges']
    scoring = 'neg_mean_absolute_error'

    # Get model
    model = XGBRegressor()
    # Define cross-validation parameters
    cv = RepeatedKFold(n_splits=num_folds, n_repeats=num_cv_iter, random_state=seed)

    # Get Hyper-parameter search class
    param_search = GridSearchCV(model,
                                hyper_param_ranges,
                                n_jobs=num_cores,
                                cv=cv,
                                scoring=scoring,
                                verbose=2)

    # Tune hyper-parameters
    search_output = param_search.fit(X_train, y_train)
    hyper_params = search_output.best_params_

    # Log findings
    log = logging.getLogger(__name__)
    log.info(f"Parameter search space: {hyper_param_ranges}")
    log.info(f"Cross-validation parameters: {cv}")
    log.info(f"Scoring: {scoring}")
    log.info(f"Best params: {hyper_params}")
    return hyper_params


def get_hyper_params(context: Any, training_data: Any, seed: int) -> Dict[str, Any]:
    """Return hyper parameters to use in model training. This can be pre-set or re-calculated"""
    log = logging.getLogger(__name__)

    if context.parameters['hyper_parameters']['tune_hyper_parameters']:
        log.info("Performing grid-search on hyper-parameter space")
        params = {'hyper_param_ranges': context.parameters['hyper_parameters']['search_grid'],
                  'cross_validation': context.parameters['cross_validation'],
                  'seed': {'seed_val': seed}}
        # TODO: START: Your code below VVV (generate variables 'x' and 'y')
        # TODO: END: Your code above ^^^
        hyper_parameters = tune_hyper_parameters(x, y, params)
        return hyper_parameters
    else:
        # Load parameters from context
        hyper_parameters = context.parameters['hyper_parameters']['pre_set_hyper_parameters']
        log.info(f"Loading pre-set hyper-parameters: {hyper_parameters}")
        return hyper_parameters


def train_model(features: DataFrame, targets: DataFrame, hyper_params: Dict[str, Any]) -> XGBRegressor:
    """Train a XGBoost model"""
    model = XGBRegressor(**hyper_params)
    model.fit(features, targets)
    return model


def get_model(training_data: Any, hyper_parameters: Dict[str, Any]) -> Any:
    """IMPLEMENT THIS FUNCTION.
    Get predictive model based on training data"""
    # TODO: START: Your code below VVV (generate variable 'model')
    # TODO: END: Your code above ^^^
    return model


def predict(model: Any, testing_data: Any) -> Any:
    """IMPLEMENT THIS FUNCTION.
    Function to predict the targets from the feature columns.
    :param model: Model used for forecasting.
    :param testing_data: Data used for testing. Structure and datatype to be defined
    :return:
    """
    # TODO: START: Your code below VVV (generate variable 'y_predicted')
    # TODO: END: Your code above ^^^
    return y_predicted


def report_model_performance(y_predicted: Any, testing_data: Any) -> None:
    """IMPLEMENT THIS FUNCTION.
    Function which logs model performance parameters which are used to decide
    whether to bring the model into production or not.
    :param y_predicted: DataFrame of the models output.
    :param testing_data: Ground truth."""
    # TODO: START: Your code below VVV (calculate and log model performance)
    log = logging.getLogger(__name__)
    log.info(f"Model performance is ...")
    # TODO: END: Your code above ^^^
