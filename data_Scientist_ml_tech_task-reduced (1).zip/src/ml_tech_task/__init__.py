"""Chief Scientist Tech Task"""
__version__ = "0.1"
