from .pipelines.data_engineering import nodes as n0
from .pipelines.data_science import nodes as n1
import logging


def run_pipeline(context):
    """Run data processing pipelines"""
    log = logging.getLogger(__name__)
    training_data, testing_data = data_engineering_pipeline(context, log)
    data_science_pipeline(context, log, training_data, testing_data)
    log.info('Finished')


def data_engineering_pipeline(context, log):
    """Run data engineering nodes"""
    log.info('Preparing the data...')
    # Load data
    filepath = str(context.project_path / context.catalog['primary_data']['filepath'])
    df = n0.get_feature_dataset_from_file(filepath)
    # Transform data
    df = n0.remove_infinities(df)
    df, encoder_labels = n0.transform_features(df)
    # Get seed (logged, for repeatability)
    if context.parameters['seed']['use_config_seed']:
        seed = context.parameters['seed']['seed_val']
    else:
        seed = n0.generate_seed()
    # Split data up
    test_ratio = context.parameters['data_prep']['test_ratio']
    training_data, testing_data = n0.split_data(df, test_ratio, seed)
    return training_data, testing_data


def data_science_pipeline(context, log, training_data, testing_data):
    """Run data science nodes"""
    log.info('Doing the modelling...')
    # Get seed (logged, for repeatability)
    if context.parameters['seed']['use_config_seed']:
        seed = context.parameters['seed']['seed_val']
    else:
        seed = n0.generate_seed()
    # Get parameters
    hyper_parameters = n1.get_hyper_params(context, training_data, seed)
    # Get model
    model = n1.get_model(training_data, hyper_parameters)
    # Perform prediction using testing data
    y_predicted = n1.predict(model, testing_data)
    # Report accuracy
    n1.report_model_performance(y_predicted, testing_data)