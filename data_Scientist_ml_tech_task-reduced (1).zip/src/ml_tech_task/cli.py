import click

from .pipeline import run_pipeline
from .context import ProjectContext

TUNE_HYPER_PARAMETERS_HELP = "Boolean flag to toggle between using a grid search and preset model values"


@click.command()
@click.option("--tune_hyper_parameters", type=bool, default=False, help=TUNE_HYPER_PARAMETERS_HELP )
def run_cli(tune_hyper_parameters):
    """Run the pipeline."""
    # Setup context
    package_name = "cds_tech_task"
    context = ProjectContext(package_name)
    context.set_tune_hyper_parameters(tune_hyper_parameters)
    # Run
    run_pipeline(context)

